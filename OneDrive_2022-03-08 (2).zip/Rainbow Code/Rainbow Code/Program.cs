﻿using System;



namespace rainbow
{
    class Program
    {
        static void Main(string[] args)
        {
            bool a = true;
            while (a==true)
            {
                var random = new Random();
                Console.ForegroundColor = (ConsoleColor)random.Next((int)ConsoleColor.Black, (int)ConsoleColor.Yellow);
                Console.BackgroundColor = (ConsoleColor)random.Next((int)ConsoleColor.Black, (int)ConsoleColor.Yellow);
                Console.WriteLine("");
            }



        }
    }
}
